#include <jni.h>
#include <string>
#include "crashlytics.h"

extern "C" JNIEXPORT jint JNICALL
Java_com_ae_app_1kt_1cl_1ndk_101_MainActivity_crashFromJNI(
        __unused JNIEnv *env,
        jobject /* this */) {

    int *foo = (int *) -1;
    printf("%d\n", *foo);
    return *foo;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_ae_app_1kt_1cl_1ndk_101_MainActivity_showCustomKeysFromJNI(
        __unused JNIEnv* env,
        jobject /* this */) {

    firebase::crashlytics::Log("Start logging!");

    firebase::crashlytics::SetUserId("id-99999");
    firebase::crashlytics::SetCustomKey("DisplayName", "Firebase Philippines");
    firebase::crashlytics::SetCustomKey("Email", "andy@gmail.com");

    firebase::crashlytics::SetCustomKey("key", "value");
    firebase::crashlytics::SetCustomKey("TAG", true);
    firebase::crashlytics::SetCustomKey("integer", 1234);
    firebase::crashlytics::SetCustomKey("float", 567.89f);
    firebase::crashlytics::SetCustomKey("timestamp", time(nullptr));

    return 0;
}

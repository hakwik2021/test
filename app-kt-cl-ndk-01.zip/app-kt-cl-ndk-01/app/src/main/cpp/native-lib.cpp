#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_ae_app_1kt_1cl_1ndk_101_MainActivity_sayHelloFromCpp(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}
package com.ae.app_kt_cl_ndk_01;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.ae.app_kt_cl_ndk_01.databinding.ActivityMainBinding;

/**
 * Android project name	    : app-kt-cl-ndk-01
 * Android application id	: com.ae.app_kt_cl_ndk_01
 * Firebase project name	: fb-cl, fb-cl-01
 * description				: Firebase Crashlytics - Test NDK Crash
 *
 * adb shell setprop log.tag.FirebaseCrashlytics DEBUG
 * adb logcat -s FirebaseCrashlytics
 *
 * $ gradlew app:assembleRelease
 * $ gradlew app:uploadCrashlyticsSymbolFileRelease
 */

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
        System.loadLibrary("manila-lib");
    }

    public native String sayHelloFromCpp();
    public native int crashFromJNI();
    public native int showCustomKeysFromJNI();


    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Example of a call to a native method
        TextView tvMessage = binding.tvMessage;
        tvMessage.setText(sayHelloFromCpp());

        Button btnCrash;
        btnCrash = findViewById(R.id.btnCrash);
        btnCrash.setOnClickListener(v -> {
            showCustomKeysFromJNI();
            crashFromJNI();
        });
    }

}